package ru.sfedu.SchoolMeals.model;

public enum CustomerType {
    PUIPLE,
    STAFF
}
