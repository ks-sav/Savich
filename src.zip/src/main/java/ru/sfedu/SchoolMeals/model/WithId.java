package ru.sfedu.SchoolMeals.model;

public interface WithId {
    long getId();
}
