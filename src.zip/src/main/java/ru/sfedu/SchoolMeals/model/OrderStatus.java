package ru.sfedu.SchoolMeals.model;


public enum OrderStatus {
    PRE,
    APPROV;
}
