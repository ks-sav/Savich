package ru.sfedu.SchoolMeals;

public class Constants {
    static public final String ENV_CONST="source";
    static public final Integer INT_CONST=88937;
    static public final String CUSTOMER_ID="id";
    static public final String CUSTOMER_NAME="name";
    static public final String CUSTOMER_FIELDS=CUSTOMER_NAME;
}
